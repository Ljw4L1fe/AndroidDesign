﻿using MySql.Data.MySqlClient;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.IO;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Threading;

namespace android_final
{
    public class PicAndSocket
    {
        public int index = 0;
        public Socket socket;
        public PicAndSocket(Socket s, int i)
        {
            index = i; socket = s;
        }
    }
    public class Client
    {
        Socket socket;
        int id = -1;

        public void SetSocket(Socket sock)
        {
            socket = sock;
        }
        public void SetId(int ID)
        {
            id = ID;
        }

        public int GetId()
        {
            return id;
        }

        public Socket GetSocket()
        {
            return socket;
        }
    }
    public class MysqlConn {
        static string mainPath = "D:\\android_user\\";
        static string defaultPath = "D:\\android_user\\Default";
        static string connetStr = "server=127.0.0.1;port=3306;user=root;password=123456; database=androiduser;";
        static int accountIndex=0;
        static int uidIndex = 0;
       
        public void Init()
        {
            try
            {
                MySqlConnection conn = new MySqlConnection(connetStr);
                conn.Open();
                string sql = "select * from init ";
                MySqlCommand cmd = new MySqlCommand(sql, conn);
                MySqlDataReader reader = cmd.ExecuteReader();
                reader.Read();
                
                Console.WriteLine("已经建立连接 accountIndex = "+reader.GetInt32(0)+"    uidIndex = "+reader.GetInt32(1));
                accountIndex = reader.GetInt32(0);
                uidIndex = reader.GetInt32(1);
                reader.Close();
                conn.Close();
                //在这里使用代码对数据库进行增删查改
            }
            catch (MySqlException ex)
            {
                Console.WriteLine(ex.Message);
            }

        }
        public void UpdateInit()
        {
            uidIndex++;
            accountIndex++;
            MySqlConnection conn = new MySqlConnection(connetStr);
            conn.Open();
            string sql = "update init set uidindex ="+uidIndex+ " , accountIndex="+accountIndex+" LIMIT 1";
            MySqlCommand cmd = new MySqlCommand(sql, conn);
            cmd.ExecuteNonQuery();
            conn.Close();
        }
        public string UpdateInfo(int account,string name,string sex,string subscription)
        {
            MySqlConnection conn = new MySqlConnection(connetStr);
            conn.Open();
            string sql = "update users set  name=\""+name+"\" ,sex=\""+sex+"\",subscription=\""+subscription+"\" where account="+account;
            MySqlCommand cmd = new MySqlCommand(sql, conn);
            if (cmd.ExecuteNonQuery() > 0)
            {
                return Tips.getTip(1, 2);
            }
            else
            {
                return Tips.getTip(0, 4);
            }


        }
        public string Register(string username,string password)
        {
            UpdateInit();
            MySqlConnection conn = new MySqlConnection(connetStr);
            conn.Open();
            string sql = "INSERT INTO users (uid,account,password,name,sex,space,subscription) VALUES ("+(uidIndex)+","+(accountIndex)+",\""+password+"\",\""+username+"\",\"未知\","+(accountIndex)+",\"这个人很懒什么都没留下\")";
           
            MySqlCommand cmd = new MySqlCommand(sql, conn);
            MySqlDataReader reader = cmd.ExecuteReader();

            if (InitUser(accountIndex))
            {
           
                return Tips.getTip(1, 1);
            }
            else
            {
                return Tips.getTip(0, 3);
            }
        }
        public string ChangePassword(int account,string orginPasswrod,string newPassword)
        {
            
            Console.WriteLine(account + "\n" + orginPasswrod + "\n" + newPassword);
            
            MySqlConnection conn = new MySqlConnection(connetStr);
            conn.Open();
            string sql = "update users set password = '"+newPassword+"' where account = "+account;
            if (CheckUser(account, orginPasswrod))
            {
                Console.WriteLine("checked");
                MySqlCommand cmd = new MySqlCommand(sql, conn);
                cmd.ExecuteNonQuery();
                conn.Close();
                return Tips.getTip(1, 0);
            }
            conn.Close();
            return Tips.getTip(0,1);
        }

        public bool InitUser(int account)
        {
            string path = mainPath + account;
            if (!Directory.Exists(path))
            {
                Directory.CreateDirectory(path);
                File.Copy(defaultPath + "\\default.jpg", path+"\\head.jpg",true);
                return true;
            }
           
            return false;
        }
        public bool CheckUser(int account, string password)
        {
            MySqlConnection conn = new MySqlConnection(connetStr);
            conn.Open();
            string sql = " select count(*) from users where account = " + account + " and password = '" + password + "'";
            MySqlCommand cmd = new MySqlCommand(sql, conn);
            MySqlDataReader reader = cmd.ExecuteReader();
            while (reader.Read())
            {
                if (reader.GetInt32(0)==1)
                {
                    conn.Close();
                    return true;
                }
                else
                {
                    conn.Close();
                    return false;
                }
          
        }
            return false;
        }
        public PersonInfo LoginCheck(int account, string password)
        {
            
            MySqlConnection conn = new MySqlConnection(connetStr);
            conn.Open();
            Console.WriteLine("CheckUser Start..... account=" + account + " || password= " + password);
            string sql = "select * from users where account = " + account + " and password = '" + password + "'";
            try
            {
                MySqlCommand cmd = new MySqlCommand(sql, conn);
                MySqlDataReader reader = cmd.ExecuteReader();//执行ExecuteReader()返回一个MySqlDataReader对象
                if (reader.HasRows)
                {
                    while (reader.Read())//初始索引是-1，执行读取下一行数据，返回值是bool
                    {
                        string filePath = mainPath + reader.GetString("space") + "\\head.jpg";
                        FileInfo fileInfo = new FileInfo(filePath);
                        Console.WriteLine("传给android的图片大小是" + fileInfo.Length);
                        FileStream stream = fileInfo.OpenRead();
                        Byte[] head = new Byte[fileInfo.Length];
                        stream.Read(head, 0, head.Length);

                       
                        PersonInfoAsString PIAS = new PersonInfoAsString(Convert.ToInt32(reader.GetString("uid")),
                            reader.GetString("name"), reader.GetString("sex"),
                            reader.GetString("subscription"), reader.GetString("space"));
                        string info = JsonConvert.SerializeObject(PIAS);
                        string pre = JsonConvert.SerializeObject(new PrePacket(Encoding.Default.GetByteCount(info), fileInfo.Length));
                        
                        PersonInfo personInfo =
                            new PersonInfo(head,info,pre);

                        reader.Close();
                        conn.Close();
                        return personInfo;

                    }
                }
                else
                {
                    Console.WriteLine("account and password are not match");
                    conn.Close();
                    reader.Close();
                    return null;
                }

            }
            catch (MySqlException e)
            {
                Console.WriteLine(e.Message);
            }
            return null;
        }

        public void Sent()
        {

        }


    }

    public class Server
    {
        MysqlConn dataBase = new MysqlConn();

        static int id = 0;//分配的ip
        //所有通信的socket
        List<Client> users = new List<Client>();
        public Server() {
            Console.WriteLine("-----------Mysql connect-----------");
            dataBase.Init();
           // Console.WriteLine(dataBase.UpdateInfo(1232150,"balala","girl","xiaomoxian"));
            Console.WriteLine("-----------Server start-----------");
            string ipv4 = GetLocalIp();
            Console.WriteLine("Server host is :" + ipv4);
            IPEndPoint ipep = new IPEndPoint(IPAddress.Parse(ipv4), 4040);
            Socket serverSocket = new Socket(ipep.AddressFamily, SocketType.Stream, ProtocolType.Tcp);
            serverSocket.Bind(ipep);
            //同时连接的最大上限  多了排队
            serverSocket.Listen(10);
            //创建后台线程一直等待连接连接
            Thread thread = new Thread(Connecting);
            thread.IsBackground = true;
            thread.Start(serverSocket);
        }

        public void Connecting(object serverSocket)
        {
            while (true)
            {
                Socket socket = (Socket)serverSocket;
                //返回通信的套接字
                try
                {
                    Socket clientSocket = socket.Accept();
                    Client client = new Client();
                    client.SetSocket(clientSocket);
                    client.SetId(id);
                    id++;
                    Console.WriteLine("Get User that id = " + id);
                    Thread thread1 = new Thread(Connecting);
                    thread1.IsBackground = true;
                    thread1.Start(serverSocket);

                    //持续接收消息
                    users.Add(client);
                    Thread thread = new Thread(GetMsg);
                    thread.IsBackground = true;
                    thread.Start(clientSocket);
                }
                catch { }
            }
        }

     
        public void GetMsg(object socketMsg)
        {
            bool stop = false;
            Socket socket = (Socket)socketMsg;
            //FileStream fs = new FileStream("D:\\qiguai.jpg", FileMode.Append);
            PersonInfo personInfo = null;
            while (true)
            {
                Byte[] buff = new Byte[1000];
                try
                {
                    int length = socket.Receive(buff);
                    //显示内容
                    string str = Encoding.UTF8.GetString(buff, 0, length);
                   
                    JObject json = JObject.Parse(str);
                    string option = json["option"].ToString();

                    //a:account:password
                    switch (option)
                    {
                        case "1":
                            Console.WriteLine("android:" + str);
                            personInfo = dataBase.LoginCheck(Convert.ToInt32(json["account"]), json["password"].ToString());
                            if (personInfo!=null)
                            {
                                Console.WriteLine("send:" + personInfo.prePacket);
                                socket.Send(Encoding.UTF8.GetBytes(personInfo.prePacket));
                            }
                            break;
                        case "2":
                            if (personInfo != null)
                            {
                                Console.WriteLine("buffer:" + personInfo.buffer.Length);
                                Console.WriteLine("info:" + personInfo.personInfoAsString);
                                socket.Send(Encoding.UTF8.GetBytes(personInfo.personInfoAsString));
                                socket.Send(personInfo.buffer);
                            }
                                // count = picIndex = Convert.ToInt32(arr[1]);
                                //PicAndSocket picAndSocket = new PicAndSocket(socket, picIndex);
                                //Thread thread = new Thread(GetPicture);
                                //thread.IsBackground = true;
                                //thread.Start(picAndSocket);
                                break;
                        case "3":
                            string result3 = dataBase.ChangePassword(Convert.ToInt32(json["account"]), json["orgPassword"].ToString(), json["newPassword"].ToString());
                            Console.WriteLine("result:"+result3);
                            socket.Send(Encoding.UTF8.GetBytes(result3));

                            break;
                        case "4":
                             string result4 = dataBase.Register(json["username"].ToString(), json["password"].ToString());
                            Console.WriteLine("result:" + result4);
                            socket.Send(Encoding.UTF8.GetBytes(result4));
                            break;
                        case "5":
                            string result5 = dataBase.UpdateInfo(Convert.ToInt32(json["account"]), json["name"].ToString(), json["sex"].ToString(), json["subscription"].ToString());
                            socket.Send(Encoding.UTF8.GetBytes(result5));
                            break;
                        case "d":
                            Console.WriteLine("d！");
                            string fileName = "D:\\andrioid\\1.jpg";
                            FileInfo fileInfo = new FileInfo(fileName);
                            Console.WriteLine("传给android的图片大小是" + fileInfo.Length);
                            FileStream stream = fileInfo.OpenRead();

                            Byte[] buffer = new Byte[fileInfo.Length];
                            stream.Read(buffer, 0, buffer.Length);

                            socket.Send(buffer);

                            break;
                        //default:
                        //    fs.Write(buff, 0, length);
                        case "test":
                            //   PersonInfo personInfo = dataBase.CheckUser(Convert.ToInt32(json["account"]), json["password"].ToString());
                            PersonInfo personInfo1 = null;
                            if (personInfo1 != null)
                            {
                                string data2 = JsonConvert.SerializeObject(personInfo1.personInfoAsString);
                                Console.WriteLine("send:" + personInfo1.buffer.Length);
                                Console.WriteLine("send:" + data2);

                                //socket.Send(Encoding.UTF8.GetBytes(data2));
                                //socket.Send(personInfo.buffer);//字符数据

                            }
                            else
                            {
                                Console.WriteLine("send:" + Tips.getTip(0,0));
                                socket.Send(Encoding.UTF8.GetBytes(Tips.getTip(0,0)));
                            }


                            stop = true;
                            break;








                            //if (picIndex == 0)
                            //{
                            //    Console.WriteLine("picIndex == 0 结束");
                            //    fs.Write(picBuff, 0, picBuff.Length);
                            //    fs.Close();

                            //    Console.WriteLine("图片大小 = " + picBuff.Length);
                            //    Console.WriteLine("图片大小1 = " + length);
                            //}
                            //else
                            //{

                            //    fs.Write(buff, 0, length);
                            //    Console.WriteLine("某一个包");
                            //    picIndex--;
                            //    buff.CopyTo(picBuff, picIndex);

                            //}
                    }


                }
                catch { }
                if (stop == true) break;
            }
        }

        public void GetPicture(object picAndSocket)
        {
            Byte[] buff = new Byte[1000];
            PicAndSocket PAS = (PicAndSocket)picAndSocket;
            int index = PAS.index;
            Socket socket = PAS.socket;
            FileStream fs = new FileStream("D:\\qiguai.jpg", FileMode.CreateNew);
            while (true)
            {
                int length = socket.Receive(buff);

                fs.Write(buff, 0, length);
                index--;
                Console.WriteLine("一个包...");
                if (index == 0)
                {
                    break;
                }
            }
            fs.Close();

        }

        public string GetLocalIp()
        {
            ///获取本地的IP地址
            string AddressIP = string.Empty;
            foreach (IPAddress _IPAddress in Dns.GetHostEntry(Dns.GetHostName()).AddressList)
            {
                if (_IPAddress.AddressFamily.ToString() == "InterNetwork")
                {
                    AddressIP = _IPAddress.ToString();
                }
            }
            return AddressIP;
        }

 

    }
    public class PersonInfo
    {
        public byte[] buffer { set; get; }
        public string personInfoAsString { set; get; }
        public string prePacket { get; set; }


        public PersonInfo(byte[] buffer, string personInfoAsString,string prePacket)
        {
            this.buffer = buffer;
            this.personInfoAsString = personInfoAsString;
            this.prePacket = prePacket;
        }
     



    }
    public class PersonInfoAsString
    {
        public int uid { get; set; }
        public string name { get; set; }
        public string sex { get; set; }
        public string space { get; set; }
        public string subscription { get; set; }

        public PersonInfoAsString(int uid, string name, string sex, string subscription, string space)
        {
            this.uid = uid;
            this.name = name;
            this.sex = sex;
            this.subscription = subscription;
            this.space = space;
        }


    }
    public class PrePacket
    {
        public int info { get; set; }
        public long imageSize { get; set; }

        public PrePacket(int infoSize,long imageSize)
        {
            this.info = infoSize;
            this.imageSize = imageSize;
        }
    }



    public static class Tips
    {
        
        static string[] errorType = new string[] {
            "账号或密码错误",
            "密码错误",
            "意料之外的错误",
            "创建账号失败",
            "修改信息失败!"
        };

        public static string getTip(int i,int j )
        {
            if(i==0)//error
                return "{\"tip\":\"" + errorType[j] + "\"}";
            else if(i==1)//helper
                return "{\"tip\":\""+helperType[j]+"\"}";
            else 
                return "{\"tip\":\"" + errorType[2] + "\"}";
        }
        static string[] helperType = new string[]
        {
            "修改密码成功!",
            "注册账号成功!",
            "修改信息成功!"
        };

    }
    class Program
    {
        static void Main(string[] args)
        {
           
            Server sv = new Server();
            while (true) ;
        }
    }
}
